#Client name: Professor Laura Atkins
#Programmer name: Brendan Boyle
#PA Purpose: Prints out the word 'fun' using the corresponding letters.
#My submission of this program indicates that I have neither received nor given substantial assistance in writing this program.

print("FFFFFFF   U     U   NN     NN")
print("FF        U     U   NNN    NN")
print("FFFFFFF   U     U   NN N   NN")
print("FF         U   U    NN  N  NN")
print("FF          UUU     NN    NNN")
